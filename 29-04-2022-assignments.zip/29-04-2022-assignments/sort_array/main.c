 /*Write a C program to sort an int array using pointers. [ increasing order / decreasing order ]*/
  
  #include<stdio.h>
  #include"sort.h"
  
 int main()
 {
   int arr[50];
   int n,i;
   printf("Enter the size of array:");
   scanf("%d",&n);
   printf("Enter the elements of the array:\n");
   for(i=0;i<n;i++)
   {
   scanf("%d",(arr+i));
   }
   sort(arr,n);
   printf("Array after sorting:\n");
   for(i=0;i<n;i++)
   {
   printf("%d ",*(arr+i));
   }
   printf("\n");
   return 0;
 }
        