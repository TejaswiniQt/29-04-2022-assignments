#include<stdio.h>
#include"main.h"

void clear_nth_bit(int num,int pos)
{
        printf("Before clear num=%d\n",num);
        num = num & ~(1<<pos-1);
        printf("After clear num=%d\n",num);
}