#include<stdio.h>
#include"main.h"

int main()
{
        int option,num,pos;
        printf("Enter the number:");
        scanf("%d",&num);
        printf("Enter the position:");
        scanf("%d",&pos);
        printf("Enter option\n1.lsb_check\n2.msb_check\n3.get_nth_bit\n4.set_nth_bit\n5.clear_nth_bit\n6.toggle_nth_bit\n");
        scanf("%d",&option);
        switch(option)
        {
                case 1:
                        lsb_check(num);
                        break;
                case 2:
                        msb_check(num);
                        break;
                case 3:
                        get_nth_bit(num,pos);
                        break;
                case 4:
                        set_nth_bit(num,pos);
                        break;
                case 5:
                        clear_nth_bit(num,pos);
                        break;
                case 6:
                        toggle_nth_bit(num,pos);
                        break;
        }
        return 0;
}