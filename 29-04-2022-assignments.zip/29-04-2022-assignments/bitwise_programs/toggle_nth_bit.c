#include<stdio.h>
#include"main.h"

void toggle_nth_bit(int num,int pos)
{
        printf("Before toggle num=%d\n",num);
        num = num ^ (1<<pos-1);
        printf("After toggle num=%d\n",num);
}