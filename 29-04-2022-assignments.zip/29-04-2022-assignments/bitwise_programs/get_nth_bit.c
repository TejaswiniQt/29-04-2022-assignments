#include<stdio.h>
#include"main.h"

void get_nth_bit(int num,int pos)
{
        int res;
        res=(num>>pos & 1);
        if(res==1)
                printf("The %d bit is set\n",pos);
        else
                printf("The %d bit is not set \n",pos);
}