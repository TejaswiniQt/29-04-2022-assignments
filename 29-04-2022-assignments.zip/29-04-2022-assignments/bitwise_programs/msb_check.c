#include<stdio.h>
#include"main.h"

void msb_check(int num)
{
        if((num>>31) & 1)
                printf("MSB is set\n");
        else
                printf("MSB is not set\n");
}