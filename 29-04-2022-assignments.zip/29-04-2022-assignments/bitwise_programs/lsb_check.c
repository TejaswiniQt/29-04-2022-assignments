#include<stdio.h>
#include"main.h"

void lsb_check(int num)
{
        if(num & 1)
                printf("LSB is set\n");
        else
                printf("LSB is not set\n");
}