void lsb_check(int num);
void msb_check(int num);
void get_nth_bit(int num,int pos);
void set_nth_bit(int num,int pos);
void clear_nth_bit(int num,int pos);
void toggle_nth_bit(int num,int pos);