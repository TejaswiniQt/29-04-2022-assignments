  /*C program to copy one array to another using pointers.*/
  
   #include<stdio.h>
   #include"copy_array.h"
  
   int main()
   {
   int src[50],des[50];
   int n,i;
   printf("Enter the size of array:");
   scanf("%d",&n);
   printf("Enter the elements of the array:\n");
   for(i=0;i<n;i++)
   {
   scanf("%d",(src+i));
   }
   copy_array(src,des,n);
   printf("The copied arry are:\n");
   for(i=0;i<n;i++)
   {
   printf("%d ",*(src+i));
   }
   printf("\n");
   return 0;
   }