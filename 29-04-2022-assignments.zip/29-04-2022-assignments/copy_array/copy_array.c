#include<stdio.h>
#include"copy_array.h"

void copy_array(int *src,int *des,int n)
{
 int i;
 for(i=0;i<n;i++)
 {
 *(des+i) = *(src+i);
 }
}