 /*Write a C program to copy one string to another string and find length of new string using pointers.*/
  
   #include<stdio.h>
   #include"copy_string.h"
   #include"str_length.h"
  
   int main()
   {
   char src[50];
   char des[50];
   int res,length;
   printf("Enter the string:");
   scanf("%[^\n]%*c",src);
   length=str_length(src);
   copy_string(src,des,length);
   printf("The copied string is: %s\n",des);
   res=str_length(des);
   printf("The length of copied string is:%d\n",res);
   return 0;
  }