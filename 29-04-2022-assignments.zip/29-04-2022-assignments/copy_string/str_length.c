#include<stdio.h>
#include"str_length.h"
  
int str_length(char *src)
{
  int length=0;
  while(*src)
  {
   length++;
   src++;
   }
   return length;
}