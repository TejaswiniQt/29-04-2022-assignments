#include<stdio.h>
#include"copy_string.h"
  
void copy_string(char *src,char *des,int length)
{
   int i=0;
   while(*(src+i))
   {
    *(des+i)=*(src+i);
    i++;
   }
   *(des+i)='\0';
}