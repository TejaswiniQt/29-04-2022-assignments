/*Write a C program to swap two numbers using pointers */
  
   #include<stdio.h>
   #include"swap.h"
  
   int main()
   {
   int a=5,b=10;
   printf("Before swapping:\n");
   printf("a=%d,b=%d\n",a,b);
   swap(&a,&b);
   printf("After swapping:\n");
   printf("a=%d,b=%d\n",a,b);
   return 0;
  }